<?php
$name='OpenSans-Regular';
$type='TTF';
$desc=array (
  'Ascent' => 1069.0,
  'Descent' => -293.0,
  'CapHeight' => 714.0,
  'Flags' => 4,
  'FontBBox' => '[-550 -271 1204 1048]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 600.0,
);
$up=-75;
$ut=50;
$ttffile='/Users/timmysab/Documents/mamp/lms/wp-content/plugins/masterstudy-lms-learning-management-system/libraries/tfpdf/font/unifont/OpenSans-Regular.ttf';
$originalsize=217276;
$fontkey='dejavu';
?>