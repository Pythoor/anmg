(function ($) {
    $(document).ready(function () {

        $('.stm_lms_start_quiz').click();
        

    });
})(jQuery);